
public class Char {
public static void main(String[] args) {
	
	for (char i='a'; i<='z'; i++){
		for(char j='a';j<='z'; j++){
			System.out.print(i);
		}
	System.out.println("");
	}
}
}

